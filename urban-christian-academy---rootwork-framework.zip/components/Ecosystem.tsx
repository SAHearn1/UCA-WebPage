
import React from 'react';
import { Cpu, Layout, Database, ExternalLink, ArrowRight, Shield } from 'lucide-react';

const Ecosystem: React.FC = () => {
  const tools = [
    {
      title: "RWFW Lesson Plan Generator",
      desc: "Instant AI-driven lesson plans that auto-align with student IEP goals and RootWork standards.",
      icon: <Cpu className="text-root-gold" size={28} />,
      link: "https://rwfw-lessonplan-generator.app/",
      tag: "FLAGSHIP",
      status: "Operational"
    },
    {
      title: "Holistic LMS",
      desc: "Learning Management System where academic rigor meets multi-modal clinical accessibility.",
      icon: <Layout className="text-root-gold" size={28} />,
      link: "#",
      tag: "PRIVATE",
      status: "Authorized Only"
    },
    {
      title: "CECS Unified SIS",
      desc: "Student Information System ensuring zero data latency between therapy and classroom.",
      icon: <Database className="text-root-gold" size={28} />,
      link: "#",
      tag: "ADMIN",
      status: "Encrypted"
    }
  ];

  return (
    <section className="py-40 bg-white relative overflow-hidden">
      {/* Background Tech Pattern */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="1"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-24 gap-12">
          <div className="max-w-2xl">
            <h2 className="text-[10px] uppercase tracking-[0.4em] font-black text-root-gold mb-8">System Architecture</h2>
            <h3 className="text-5xl md:text-7xl font-bold text-gray-900 serif leading-none">
              Built for <br />
              <span className="italic">Impact</span>.
            </h3>
          </div>
          <div className="bg-gray-50 p-8 rounded-3xl border border-gray-100 shadow-sm max-w-sm">
            <div className="flex items-center space-x-3 mb-4 text-blue-600">
              <Shield size={20} />
              <span className="text-[10px] uppercase tracking-widest font-black">Security Verified</span>
            </div>
            <p className="text-sm text-gray-500 font-light leading-relaxed">
              Our proprietary stack ensures HIPAA and FERPA compliance while delivering real-time pedagogical insights.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {tools.map((tool, idx) => (
            <div key={idx} className="bg-[#f9f9f9] rounded-3xl p-10 group hover:bg-root-dark transition-all duration-700 hover:shadow-[0_50px_100px_-20px_rgba(12,26,37,0.3)]">
              <div className="flex justify-between items-start mb-12">
                <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-lg group-hover:bg-root-gold transition-colors duration-500">
                  {React.cloneElement(tool.icon as React.ReactElement, { className: 'group-hover:text-white transition-colors duration-500' })}
                </div>
                <div className="text-right">
                  <span className="block text-[8px] uppercase tracking-[0.2em] font-black text-gray-300 mb-1 group-hover:text-root-gold">{tool.tag}</span>
                  <span className="block text-[9px] font-bold text-green-500">{tool.status}</span>
                </div>
              </div>
              
              <h4 className="text-2xl font-bold text-gray-900 serif mb-6 group-hover:text-white transition-colors">{tool.title}</h4>
              <p className="text-gray-500 text-sm leading-relaxed mb-12 font-light group-hover:text-gray-400 transition-colors">
                {tool.desc}
              </p>
              
              <a 
                href={tool.link} 
                target="_blank" 
                className="inline-flex items-center text-[10px] uppercase tracking-widest font-black text-root-gold group-hover:text-white transition-all pt-6 border-t border-gray-100 group-hover:border-white/10 w-full"
              >
                Deploy Engine
                <ArrowRight className="ml-3 group-hover:translate-x-3 transition-transform" size={14} />
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Ecosystem;
