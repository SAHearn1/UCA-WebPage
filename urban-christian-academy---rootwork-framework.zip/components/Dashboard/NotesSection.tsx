
import React, { useState, useEffect } from 'react';
import { User } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  serverTimestamp,
  deleteDoc,
  doc 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { db } from '../../services/firebase';
import { Plus, Notebook, Loader2, X, MessageSquare, Trash2, Search, Calendar } from 'lucide-react';

interface NotesSectionProps {
  user: User;
}

const NotesSection: React.FC<NotesSectionProps> = ({ user }) => {
  const [notes, setNotes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Modal states
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'users', user.uid, 'notes'), (snap) => {
      setNotes(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    });
    return () => unsub();
  }, [user.uid]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    setSaving(true);
    try {
      await addDoc(collection(db, 'users', user.uid, 'notes'), {
        title,
        content,
        createdAt: serverTimestamp(),
      });
      setIsModalOpen(false);
      setTitle('');
      setContent('');
    } catch (err) { console.error(err); }
    finally { setSaving(false); }
  };

  const deleteNote = async (id: string) => {
    if (confirm('Delete this research note?')) {
      await deleteDoc(doc(db, 'users', user.uid, 'notes', id));
    }
  };

  const filteredNotes = notes.filter(n => 
    n.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    n.content?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h2 className="text-4xl font-bold text-gray-900 serif">Research Hub</h2>
          <p className="text-sm text-gray-500 mt-2 font-light">Document observations, pedagogical shifts, and framework milestones.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center px-8 py-5 bg-[#B8860B] text-white font-black uppercase tracking-[0.2em] text-[10px] rounded-2xl shadow-xl hover:bg-[#8B6508] transition-all"
        >
          <Plus size={18} className="mr-3" />
          Draft Memo
        </button>
      </div>

      <div className="mb-10 relative">
        <div className="absolute inset-y-0 left-6 flex items-center pointer-events-none">
          <Search size={16} className="text-gray-300" />
        </div>
        <input 
          type="text" 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Filter research by keyword..."
          className="w-full pl-16 pr-8 py-5 bg-white border border-gray-100 rounded-3xl shadow-sm outline-none focus:ring-2 focus:ring-root-gold transition-all text-sm font-light"
        />
      </div>

      {loading ? (
        <div className="py-40 flex justify-center"><Loader2 className="animate-spin text-gray-200" size={40} /></div>
      ) : filteredNotes.length === 0 ? (
        <div className="bg-white border-2 border-dashed border-gray-100 rounded-[3rem] p-24 text-center">
          <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-8 text-gray-200">
            <Notebook size={32} />
          </div>
          <h4 className="text-2xl font-bold text-gray-900 serif mb-4">The library is empty</h4>
          <p className="text-sm text-gray-400 max-w-sm mx-auto font-light leading-relaxed">Your research and pedagogical memos will appear here. Start your first RootWork observation today.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredNotes.map(note => (
            <div key={note.id} className="group bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-2xl transition-all duration-700 flex flex-col relative overflow-hidden">
              <div className="flex justify-between items-start mb-8">
                <div className="w-12 h-12 bg-blue-50 text-blue-500 rounded-2xl flex items-center justify-center group-hover:bg-blue-500 group-hover:text-white transition-all duration-500">
                  <Notebook size={20} />
                </div>
                <button 
                  onClick={() => deleteNote(note.id)}
                  className="p-2 text-gray-100 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                >
                  <Trash2 size={16} />
                </button>
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 serif mb-6 leading-[1.1] group-hover:text-root-gold transition-colors">{note.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed font-light line-clamp-6 mb-10 flex-grow">{note.content}</p>
              
              <div className="pt-8 border-t border-gray-50 flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-gray-300">
                <div className="flex items-center">
                  <Calendar size={12} className="mr-2" />
                  <span>{note.createdAt?.toDate().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                </div>
                <span className="text-root-gold opacity-0 group-hover:opacity-100 transition-opacity">Read Full Memo</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Note Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-root-dark/80 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in duration-300">
            <div className="p-16">
              <div className="flex justify-between items-center mb-12">
                <div>
                  <h4 className="text-3xl font-bold text-gray-900 serif">Research Memo</h4>
                  <p className="text-[10px] uppercase tracking-widest font-black text-root-gold mt-2">New Entry | {new Date().toLocaleDateString()}</p>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="w-12 h-12 flex items-center justify-center bg-gray-50 rounded-full text-gray-400 hover:text-gray-900 transition-all">
                  <X size={24} />
                </button>
              </div>
              
              <form onSubmit={handleCreate} className="space-y-10">
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] font-black text-gray-400 mb-4">Subject Heading</label>
                  <input 
                    type="text" 
                    required
                    autoFocus
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full text-2xl font-bold serif border-b border-gray-100 pb-4 outline-none focus:border-root-gold transition-colors placeholder:text-gray-200"
                    placeholder="E.g., Observational Grit in Grade 4 Math..."
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] font-black text-gray-400 mb-4">Core Synthesis</label>
                  <textarea 
                    rows={8}
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    className="w-full bg-gray-50/50 p-8 rounded-3xl outline-none focus:ring-2 focus:ring-root-gold text-sm font-light leading-relaxed placeholder:text-gray-300"
                    placeholder="Log your framework developments here..."
                  />
                </div>
                
                <div className="flex space-x-6 pt-4">
                  <button 
                    type="submit" 
                    disabled={saving} 
                    className="flex-1 py-6 bg-root-dark text-white text-[11px] font-black uppercase tracking-[0.3em] rounded-2xl shadow-2xl hover:bg-black transition-all flex items-center justify-center"
                  >
                    {saving ? <Loader2 className="animate-spin" size={18} /> : 'Archive Research'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NotesSection;
