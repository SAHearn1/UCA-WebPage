
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Partnership from './components/Partnership';
import RootWorkSection from './components/RootWorkSection';
import Ecosystem from './components/Ecosystem';
import Footer from './components/Footer';
import AuthModal from './components/AuthModal';
import Dashboard from './components/Dashboard/Dashboard';
import { auth } from './services/firebase';
import { onAuthStateChanged, User } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'home' | 'framework' | 'dashboard'>('home');
  const [user, setUser] = useState<User | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        setIsAuthModalOpen(false);
        setActiveTab('dashboard'); // Redirect to dashboard on login
      } else {
        setActiveTab('home');
      }
    });
    return () => unsubscribe();
  }, []);

  const openAuth = (mode: 'signin' | 'signup') => {
    setAuthMode(mode);
    setIsAuthModalOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header 
        onNavigate={setActiveTab} 
        activeTab={activeTab} 
        user={user} 
        onLogin={() => openAuth('signin')}
      />
      
      <main className="flex-grow">
        {user && activeTab === 'dashboard' ? (
          <Dashboard user={user} />
        ) : (
          <>
            {activeTab === 'home' && (
              <>
                <Hero onAuthRequired={openAuth} user={user} />
                <Partnership />
                <Ecosystem />
              </>
            )}
            
            {activeTab === 'framework' && (
              <RootWorkSection />
            )}
          </>
        )}
      </main>

      <Footer />

      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
        initialMode={authMode}
      />
    </div>
  );
};

export default App;
