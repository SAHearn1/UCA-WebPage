
import React, { useState } from 'react';
import { User } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { 
  Folder, 
  Users, 
  Notebook, 
  ChevronRight, 
  LayoutDashboard,
  Bell,
  Search,
  Settings
} from 'lucide-react';
import OverviewSection from './OverviewSection';
import FilesSection from './FilesSection';
import NotesSection from './NotesSection';
import TeamSection from './TeamSection';

interface DashboardProps {
  user: User;
}

const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  const [activeView, setActiveView] = useState<'overview' | 'files' | 'notes' | 'team'>('overview');

  const navItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'files', label: 'My Files', icon: Folder },
    { id: 'notes', label: 'My Notes', icon: Notebook },
    { id: 'team', label: 'Team Members', icon: Users },
  ];

  return (
    <div className="min-h-screen bg-[#fcfcfc] flex flex-col md:flex-row">
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-72 bg-white border-r border-gray-100 flex flex-col sticky top-0 h-screen overflow-y-auto">
        <div className="p-8">
          <div className="flex items-center space-x-3 mb-12">
            <div className="w-10 h-10 bg-root-dark rounded-xl flex items-center justify-center text-root-gold shadow-lg">
              <LayoutDashboard size={20} />
            </div>
            <div>
              <p className="text-xs font-black uppercase tracking-[0.2em] text-gray-900">UCA Workspace</p>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">v2.4.0-Flash</p>
            </div>
          </div>

          <nav className="space-y-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveView(item.id as any)}
                className={`w-full flex items-center justify-between px-4 py-4 rounded-2xl text-[11px] uppercase tracking-widest font-black transition-all duration-300 ${
                  activeView === item.id 
                  ? 'bg-root-dark text-white shadow-[0_20px_40px_-10px_rgba(12,26,37,0.3)]' 
                  : 'text-gray-400 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center">
                  <item.icon size={18} className={`mr-4 ${activeView === item.id ? 'text-root-gold' : 'text-gray-300'}`} />
                  <span>{item.label}</span>
                </div>
                {activeView === item.id && <div className="w-1.5 h-1.5 rounded-full bg-root-gold" />}
              </button>
            ))}
          </nav>
        </div>

        <div className="mt-auto p-8 border-t border-gray-50">
          <div className="p-6 bg-gray-50 rounded-2xl border border-gray-100 mb-8">
            <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Academic Status</p>
            <div className="flex items-center space-x-2">
              <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                <div className="h-full bg-root-gold w-3/4 rounded-full" />
              </div>
              <span className="text-[10px] font-black text-gray-900">75%</span>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-root-dark border-2 border-root-gold flex items-center justify-center text-root-gold font-black text-xs shadow-lg">
                {user.email?.[0].toUpperCase()}
              </div>
              <div className="overflow-hidden">
                <p className="text-[11px] font-black text-gray-900 truncate w-32 uppercase tracking-tighter">{user.email?.split('@')[0]}</p>
                <p className="text-[9px] text-gray-400 uppercase tracking-widest font-bold">Standard Account</p>
              </div>
            </div>
            <button className="text-gray-300 hover:text-gray-600">
              <Settings size={16} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-grow">
        {/* Top Header */}
        <div className="h-20 bg-white border-b border-gray-50 flex items-center justify-between px-10 sticky top-0 z-40 backdrop-blur-md bg-white/80">
          <div className="flex items-center bg-gray-50 px-4 py-2 rounded-full border border-gray-100 min-w-[300px]">
            <Search size={16} className="text-gray-300 mr-3" />
            <input 
              type="text" 
              placeholder="Search assets, notes, members..." 
              className="bg-transparent border-none outline-none text-[10px] uppercase tracking-widest font-bold w-full"
            />
          </div>
          <div className="flex items-center space-x-6">
            <button className="relative text-gray-400 hover:text-gray-900 transition-colors">
              <Bell size={20} />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-root-gold rounded-full border-2 border-white" />
            </button>
            <div className="h-6 w-[1px] bg-gray-100" />
            <div className="text-right">
              <p className="text-[10px] font-black uppercase tracking-widest text-gray-900">{new Date().toLocaleDateString('en-US', { weekday: 'long' })}</p>
              <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">{new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
            </div>
          </div>
        </div>

        <div className="p-10 max-w-7xl mx-auto">
          {activeView === 'overview' && <OverviewSection user={user} onNavigate={setActiveView} />}
          {activeView === 'files' && <FilesSection user={user} />}
          {activeView === 'notes' && <NotesSection user={user} />}
          {activeView === 'team' && <TeamSection user={user} />}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
