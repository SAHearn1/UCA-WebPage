
import { GoogleGenAI, Type } from "@google/genai";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async researchFramework(topic: string) {
    const response = await this.ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Explain the importance of ${topic} within the context of 'The RootWork Framework' for an urban educational setting. Sourced from conceptual authoritative documents on evidence-based urban pedagogy.`,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text;
  }

  async generateLessonPlanSnippet(subject: string, grade: string) {
    const response = await this.ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a lesson plan snippet for ${subject} at ${grade} grade level, following the RootWork Framework methodology (Root, Work, Growth).`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            objective: { type: Type.STRING },
            rootActivity: { type: Type.STRING },
            workActivity: { type: Type.STRING },
            growthBenchmark: { type: Type.STRING }
          },
          required: ["title", "objective", "rootActivity", "workActivity", "growthBenchmark"]
        }
      }
    });
    return JSON.parse(response.text);
  }
}
