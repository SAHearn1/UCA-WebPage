
import React from 'react';
import { ShieldCheck, Users, Target, Zap, Building2, Sprout } from 'lucide-react';

const Partnership: React.FC = () => {
  const points = [
    { 
      icon: <Building2 className="text-white" size={24} />, 
      title: "UCA Governance", 
      text: "Faith-based leadership providing the moral and ethical scaffolding for our urban student population." 
    },
    { 
      icon: <Users className="text-white" size={24} />, 
      title: "CECS Clinical Hub", 
      text: "Expert therapists and case managers delivering specialized interventions within the daily classroom flow." 
    },
    { 
      icon: <Target className="text-white" size={24} />, 
      title: "Precision Outcomes", 
      text: "Every instructional hour is mapped to clinical data, ensuring no child is left behind in the urban grid." 
    },
    { 
      icon: <Sprout className="text-white" size={24} />, 
      title: "Rooted Identity", 
      text: "The RootWork Framework™ ensures academic rigor is paired with cultural responsiveness." 
    },
  ];

  return (
    <section className="py-32 bg-white relative overflow-hidden">
      {/* Visual Bridge Decorative Element */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-root-gold to-transparent opacity-30" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row gap-20 items-center">
          <div className="lg:w-1/2">
            <h2 className="text-[10px] uppercase tracking-[0.4em] font-black text-root-gold mb-8">The Integration</h2>
            <h3 className="text-5xl md:text-6xl font-bold text-gray-900 serif leading-none mb-10">
              One Vision. <br />
              <span className="italic">Unified</span> Power.
            </h3>
            <p className="text-xl text-gray-500 font-light leading-relaxed mb-12">
              The partnership between Urban Christian Academy and Community Exceptional Children’s Services is more than a contract—it is a symbiotic ecosystem.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-10">
              {points.map((p, i) => (
                <div key={i} className="group">
                  <div className="mb-6 w-12 h-12 bg-root-dark rounded-xl flex items-center justify-center group-hover:bg-root-gold transition-colors duration-500 shadow-xl">
                    {p.icon}
                  </div>
                  <h4 className="text-lg font-bold text-gray-900 mb-2 serif">{p.title}</h4>
                  <p className="text-sm text-gray-400 leading-relaxed font-light">{p.text}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:w-1/2 relative">
            <div className="relative z-10 grid grid-cols-2 gap-4">
              <div className="space-y-4 pt-12">
                <div className="rounded-2xl shadow-2xl overflow-hidden bg-gray-100">
                  <img 
                    src="https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&q=80&w=600" 
                    className="w-full h-auto hover:scale-105 transition-transform duration-700" 
                    alt="UCA Campus"
                  />
                </div>
                <div className="bg-root-gold p-6 rounded-2xl text-white shadow-xl">
                  <p className="text-3xl font-bold serif">200+</p>
                  <p className="text-[9px] uppercase tracking-widest font-black">Lives Impacted</p>
                </div>
              </div>
              <div className="space-y-4">
                <div className="bg-root-dark p-6 rounded-2xl text-white shadow-xl">
                  <p className="text-3xl font-bold serif">CECS</p>
                  <p className="text-[9px] uppercase tracking-widest font-black">Clinical Standard</p>
                </div>
                <div className="rounded-2xl shadow-2xl overflow-hidden bg-gray-100">
                  <img 
                    src="https://images.unsplash.com/photo-1543269865-cbf427effbad?auto=format&fit=crop&q=80&w=600" 
                    className="w-full h-auto hover:scale-105 transition-transform duration-700" 
                    alt="Collaborative Work"
                  />
                </div>
              </div>
            </div>
            
            {/* Background branding */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[20rem] font-black text-gray-50 -z-0 select-none opacity-20">
              UCA
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Partnership;
