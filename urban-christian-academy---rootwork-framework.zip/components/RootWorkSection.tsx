
import React from 'react';
import { CheckCircle2, Sprout, Layers, Zap, ArrowRight, ShieldCheck } from 'lucide-react';

const RootWorkSection: React.FC = () => {
  const stages = [
    {
      label: "Phase 01",
      title: "Rooting",
      desc: "Identity, Ethos, and Cultural Responsiveness. We ground the student in their heritage before exploring the future.",
      icon: <Sprout size={40} className="text-root-gold" />,
      color: "border-b-root-gold"
    },
    {
      label: "Phase 02",
      title: "Working",
      desc: "Rigorous Inquiry and Collaborative Practice. Deploying logic and grit to master state standards.",
      icon: <Layers size={40} className="text-blue-500" />,
      color: "border-b-blue-500"
    },
    {
      label: "Phase 03",
      title: "Growing",
      desc: "Community Contribution and Academic Mastery. Reaching outward to lead and serve.",
      icon: <Zap size={40} className="text-green-500" />,
      color: "border-b-green-500"
    }
  ];

  return (
    <section className="bg-[#0c1a25]">
      {/* Immersive Framework Intro */}
      <div className="relative py-40 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-20">
          <img 
            src="https://images.unsplash.com/photo-1617331721458-bd3bd3f9c7f8?auto=format&fit=crop&q=80&w=1600" 
            className="w-full h-full object-cover grayscale brightness-75" 
            alt="Children in greenhouse"
          />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <div className="inline-flex items-center space-x-3 text-root-gold mb-12">
            <div className="h-[1px] w-12 bg-root-gold/30" />
            <span className="text-[10px] uppercase tracking-[0.4em] font-black">The Proprietary Pedagogy</span>
            <div className="h-[1px] w-12 bg-root-gold/30" />
          </div>
          <h3 className="text-6xl md:text-9xl font-bold serif text-white mb-12 leading-none">
            The RootWork <br />
            <span className="text-root-gold">Framework™</span>
          </h3>
          <p className="max-w-2xl mx-auto text-lg text-gray-400 font-light leading-relaxed">
            Methodology is the soul of achievement. The RWFW converts urban challenges into educational advantages through clinical precision.
          </p>
        </div>
      </div>

      {/* The Journey Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-24 pb-40">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stages.map((stage, i) => (
            <div key={i} className={`bg-white p-12 shadow-[0_50px_100px_rgba(0,0,0,0.3)] border-b-8 ${stage.color} group hover:-translate-y-4 transition-all duration-500`}>
              <p className="text-[10px] uppercase tracking-[0.2em] font-black text-gray-400 mb-10">{stage.label}</p>
              <div className="mb-10 transform group-hover:scale-110 transition-transform duration-500">{stage.icon}</div>
              <h4 className="text-4xl font-bold text-gray-900 serif mb-6">{stage.title}</h4>
              <p className="text-gray-500 leading-relaxed font-light mb-12">{stage.desc}</p>
              <div className="flex items-center text-[10px] font-black uppercase tracking-widest text-gray-900 border-t border-gray-100 pt-8 group-hover:text-root-gold transition-colors cursor-pointer">
                Learn Methodology <ArrowRight className="ml-2 group-hover:translate-x-2 transition-transform" size={14} />
              </div>
            </div>
          ))}
        </div>

        {/* Clinical Bridge Content */}
        <div className="mt-40 grid lg:grid-cols-2 gap-20 items-center">
          <div className="order-2 lg:order-1">
             <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white/10">
               <img 
                 src="https://images.unsplash.com/photo-1581056310667-00465f583e91?auto=format&fit=crop&q=80&w=1200" 
                 className="w-full h-[500px] object-cover mix-blend-luminosity grayscale opacity-60" 
                 alt="Clinical Support in Garden"
               />
               <div className="absolute inset-0 flex items-center justify-center">
                 <div className="bg-root-gold p-8 rounded-full shadow-2xl animate-pulse">
                   <ShieldCheck className="text-white" size={48} />
                 </div>
               </div>
             </div>
          </div>
          <div className="order-1 lg:order-2 text-white">
            <h4 className="text-[10px] uppercase tracking-[0.4em] font-black text-root-gold mb-8">Clinical Synergy</h4>
            <h5 className="text-4xl font-bold serif mb-10">Where Clinical <br />meets Classroom.</h5>
            <div className="space-y-8">
              <div className="flex items-start">
                <div className="mt-1 mr-6 text-root-gold font-bold serif text-xl italic">01.</div>
                <p className="text-gray-400 font-light leading-relaxed">Integrated IEP benchmarks updated in real-time within the Lesson Plan Generator.</p>
              </div>
              <div className="flex items-start">
                <div className="mt-1 mr-6 text-root-gold font-bold serif text-xl italic">02.</div>
                <p className="text-gray-400 font-light leading-relaxed">Multi-disciplinary teams (Educators + Therapists) collaborating on every student profile.</p>
              </div>
              <div className="flex items-start">
                <div className="mt-1 mr-6 text-root-gold font-bold serif text-xl italic">03.</div>
                <p className="text-gray-400 font-light leading-relaxed">Holistic character development benchmarks tracked via the CECS-LMS dashboard.</p>
              </div>
            </div>
            <button className="mt-16 px-10 py-5 bg-white text-root-dark font-black uppercase tracking-widest text-[10px] rounded hover:bg-root-gold hover:text-white transition-all shadow-2xl">
              Request Practitioner Access
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default RootWorkSection;
