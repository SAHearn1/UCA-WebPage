
import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Activity } from 'lucide-react';
import { Agent, AgentStatus } from '../types';
import { AGENT_DEFINITIONS, getIconForAgent } from '../constants';

const AgentOrchestrator: React.FC = () => {
  const [agents, setAgents] = useState<Agent[]>(AGENT_DEFINITIONS);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    let interval: any;
    if (isRunning) {
      interval = setInterval(() => {
        setAgents(prev => prev.map(agent => {
          if (agent.progress >= 100) return { ...agent, status: AgentStatus.COMPLETED, progress: 100 };
          
          const step = Math.random() * 5;
          const newProgress = Math.min(100, agent.progress + step);
          const updates = [
            "Analyzing Drive files...", 
            "Verifying CECS partnership...", 
            "Generating RootWork content...", 
            "Optimizing frontend UI...", 
            "Running legal audit...", 
            "Testing E2E logic..."
          ];
          
          return {
            ...agent,
            progress: newProgress,
            status: AgentStatus.RUNNING,
            lastUpdate: updates[Math.floor(Math.random() * updates.length)]
          };
        }));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  const toggleOrchestration = () => setIsRunning(!isRunning);
  const resetOrchestration = () => {
    setIsRunning(false);
    setAgents(AGENT_DEFINITIONS);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-12">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 serif">Agent Command Center</h2>
          <p className="text-gray-500 mt-2">Managing the deployment of parallel-running agents for the UCA build.</p>
        </div>
        
        <div className="mt-6 md:mt-0 flex space-x-3">
          <button 
            onClick={toggleOrchestration}
            className={`flex items-center px-4 py-2 rounded-lg font-bold transition-all ${isRunning ? 'bg-amber-100 text-amber-700' : 'bg-blue-600 text-white shadow-lg'}`}
          >
            {isRunning ? <><Pause className="mr-2" size={18} /> Pause</> : <><Play className="mr-2" size={18} /> Deploy Agents</>}
          </button>
          <button 
            onClick={resetOrchestration}
            className="flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-bold hover:bg-gray-200"
          >
            <RotateCcw className="mr-2" size={18} /> Reset
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {agents.map((agent) => (
          <div key={agent.id} className="bg-white rounded-xl border border-gray-100 shadow-sm p-6 overflow-hidden relative">
            <div className="flex justify-between items-start mb-4">
              <div className={`p-2 rounded-lg ${agent.status === AgentStatus.RUNNING ? 'bg-blue-50 text-blue-600' : 'bg-gray-50 text-gray-400'}`}>
                {getIconForAgent(agent.id)}
              </div>
              <span className={`text-[10px] uppercase font-bold px-2 py-1 rounded-full ${
                agent.status === AgentStatus.RUNNING ? 'bg-blue-100 text-blue-700' : 
                agent.status === AgentStatus.COMPLETED ? 'bg-green-100 text-green-700' : 
                'bg-gray-100 text-gray-500'
              }`}>
                {agent.status}
              </span>
            </div>
            
            <h3 className="font-bold text-gray-900">{agent.name}</h3>
            <p className="text-xs text-gray-500 mb-6">{agent.role}</p>
            
            <div className="space-y-2">
              <div className="flex justify-between text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                <span>Progress</span>
                <span>{Math.round(agent.progress)}%</span>
              </div>
              <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-1000 ${agent.progress === 100 ? 'bg-green-500' : 'bg-blue-600'}`}
                  style={{ width: `${agent.progress}%` }}
                />
              </div>
              <p className="text-[10px] italic text-gray-400 truncate">{agent.lastUpdate}</p>
            </div>

            {agent.status === AgentStatus.RUNNING && (
              <div className="absolute top-2 right-2">
                <Activity size={12} className="text-blue-400 animate-pulse" />
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-16 bg-blue-50 rounded-2xl p-8 border border-blue-100">
        <div className="flex items-start">
          <Activity className="text-blue-600 mt-1 mr-4" />
          <div>
            <h4 className="text-blue-900 font-bold mb-2">Live Orchestration Logs</h4>
            <div className="bg-white/50 rounded-lg p-4 font-mono text-[11px] text-blue-800 space-y-1 h-32 overflow-y-auto">
              <p>[08:01:23] Research Agent: Sourcing UCA-CECS Partnership Agreement from Drive...</p>
              <p>[08:01:25] Compliance Agent: Verifying trademark status of "The RootWork Framework"...</p>
              <p>[08:01:28] Design Agent: Pulling CSS variables from rwfw-lessonplan-generator.app...</p>
              {isRunning && <p className="animate-pulse">[SYSTEM] Streaming parallel workloads to 8 clusters...</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgentOrchestrator;
