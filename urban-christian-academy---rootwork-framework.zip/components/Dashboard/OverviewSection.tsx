
import React, { useState, useEffect } from 'react';
import { User } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { 
  collection, 
  onSnapshot 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { db } from '../../services/firebase';
import { 
  Folder, 
  Notebook, 
  Users, 
  FileText, 
  Plus, 
  ArrowUpRight,
  TrendingUp,
  Clock
} from 'lucide-react';

interface OverviewSectionProps {
  user: User;
  onNavigate: (view: any) => void;
}

const OverviewSection: React.FC<OverviewSectionProps> = ({ user, onNavigate }) => {
  const [stats, setStats] = useState({
    files: 0,
    folders: 0,
    notes: 0,
    members: 0
  });

  useEffect(() => {
    const unsubFolders = onSnapshot(collection(db, 'users', user.uid, 'folders'), (s) => setStats(prev => ({ ...prev, folders: s.size })));
    const unsubFiles = onSnapshot(collection(db, 'users', user.uid, 'files'), (s) => setStats(prev => ({ ...prev, files: s.size })));
    const unsubNotes = onSnapshot(collection(db, 'users', user.uid, 'notes'), (s) => setStats(prev => ({ ...prev, notes: s.size })));
    const unsubMembers = onSnapshot(collection(db, 'users', user.uid, 'teamMembers'), (s) => setStats(prev => ({ ...prev, members: s.size })));

    return () => {
      unsubFolders();
      unsubFiles();
      unsubNotes();
      unsubMembers();
    };
  }, [user.uid]);

  const cards = [
    { id: 'files', label: 'Stored Files', count: stats.files, icon: Folder, color: 'text-root-gold', bg: 'bg-root-gold/10' },
    { id: 'notes', label: 'Research Notes', count: stats.notes, icon: Notebook, color: 'text-blue-500', bg: 'bg-blue-50' },
    { id: 'team', label: 'Team Members', count: stats.members, icon: Users, color: 'text-green-500', bg: 'bg-green-50' },
  ];

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-4xl font-bold text-gray-900 serif">Welcome back, {user.email?.split('@')[0]}</h2>
          <p className="text-sm text-gray-500 mt-2 font-light">Here's a summary of your RootWork Framework activity today.</p>
        </div>
        <div className="flex -space-x-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="w-10 h-10 rounded-full border-4 border-white bg-gray-200 flex items-center justify-center text-[10px] font-bold text-gray-500">
              {i}
            </div>
          ))}
          <div className="w-10 h-10 rounded-full border-4 border-white bg-root-gold text-white flex items-center justify-center text-[10px] font-bold">
            +{stats.members}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {cards.map((card) => (
          <button 
            key={card.id}
            onClick={() => onNavigate(card.id)}
            className="group bg-white p-8 rounded-3xl border border-gray-100 shadow-sm hover:shadow-2xl transition-all duration-500 text-left relative overflow-hidden"
          >
            <div className={`w-12 h-12 ${card.bg} ${card.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-500`}>
              <card.icon size={24} />
            </div>
            <p className="text-[10px] uppercase tracking-[0.2em] font-black text-gray-400 mb-1">{card.label}</p>
            <p className="text-4xl font-bold text-gray-900 serif">{card.count}</p>
            <div className="absolute top-8 right-8 text-gray-100 group-hover:text-root-gold transition-colors">
              <ArrowUpRight size={24} />
            </div>
            <div className="mt-6 flex items-center space-x-2 text-[10px] font-black text-green-500 uppercase tracking-widest">
              <TrendingUp size={12} />
              <span>+12% this week</span>
            </div>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-root-dark rounded-3xl p-10 text-white relative overflow-hidden">
          <div className="relative z-10">
            <h3 className="text-2xl font-bold serif mb-4">Quick Deploy</h3>
            <p className="text-gray-400 text-sm font-light leading-relaxed mb-8 max-w-xs">Instantly generate a new RootWork lesson plan or research memo.</p>
            <div className="flex space-x-4">
              <button className="flex items-center space-x-3 px-6 py-4 bg-root-gold text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg hover:bg-opacity-90 transition-all">
                <Plus size={16} />
                <span>New LP</span>
              </button>
              <button className="flex items-center space-x-3 px-6 py-4 bg-white/10 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-white/20 transition-all">
                <Notebook size={16} />
                <span>New Note</span>
              </button>
            </div>
          </div>
          <div className="absolute top-1/2 right-[-10%] -translate-y-1/2 opacity-10">
            <TrendingUp size={300} strokeWidth={1} />
          </div>
        </div>

        <div className="bg-white border border-gray-100 rounded-3xl p-10 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-bold text-gray-900 serif">System Logs</h3>
            <Clock size={18} className="text-gray-300" />
          </div>
          <div className="space-y-6">
            {[
              { t: 'File Synchronized', d: 'Literacy_Plan_G4.pdf', time: '2m ago' },
              { t: 'New Member Added', d: 'Dr. Sarah Wilson', time: '1h ago' },
              { t: 'Framework Update', d: 'Pedagogy Logic v2.4', time: '4h ago' },
            ].map((log, i) => (
              <div key={i} className="flex items-start justify-between group cursor-pointer">
                <div className="flex items-center space-x-4">
                  <div className="w-2 h-2 rounded-full bg-root-gold group-hover:scale-150 transition-transform" />
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-gray-900">{log.t}</p>
                    <p className="text-xs text-gray-400 font-light">{log.d}</p>
                  </div>
                </div>
                <span className="text-[9px] font-bold text-gray-300 uppercase">{log.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OverviewSection;
