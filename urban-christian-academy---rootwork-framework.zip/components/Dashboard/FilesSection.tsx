
import React, { useState, useEffect } from 'react';
import { User } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  serverTimestamp,
  deleteDoc,
  doc
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { db } from '../../services/firebase';
import { 
  FolderPlus, 
  FilePlus, 
  Folder, 
  File, 
  Loader2, 
  X, 
  MoreVertical,
  ChevronLeft,
  Trash2,
  ExternalLink
} from 'lucide-react';

interface FilesSectionProps {
  user: User;
}

const FilesSection: React.FC<FilesSectionProps> = ({ user }) => {
  const [folders, setFolders] = useState<any[]>([]);
  const [files, setFiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFolder, setActiveFolder] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<'folder' | 'file' | null>(null);
  
  // Modal states
  const [newName, setNewName] = useState('');
  const [fileSize, setFileSize] = useState('0.8 MB');
  const [selectedFolderId, setSelectedFolderId] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const foldersRef = collection(db, 'users', user.uid, 'folders');
    const filesRef = collection(db, 'users', user.uid, 'files');

    const unsubFolders = onSnapshot(foldersRef, (snap) => {
      setFolders(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    });

    const unsubFiles = onSnapshot(filesRef, (snap) => {
      setFiles(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    return () => {
      unsubFolders();
      unsubFiles();
    };
  }, [user.uid]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    setSaving(true);

    try {
      if (isModalOpen === 'folder') {
        await addDoc(collection(db, 'users', user.uid, 'folders'), {
          name: newName,
          createdAt: serverTimestamp(),
        });
      } else {
        await addDoc(collection(db, 'users', user.uid, 'files'), {
          name: newName,
          folderId: activeFolder || selectedFolderId || null,
          size: fileSize,
          createdAt: serverTimestamp(),
        });
      }
      setIsModalOpen(null);
      setNewName('');
      setSelectedFolderId('');
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const deleteItem = async (type: 'files' | 'folders', id: string) => {
    if (confirm(`Delete this ${type.slice(0, -1)}?`)) {
      await deleteDoc(doc(db, 'users', user.uid, type, id));
      if (type === 'folders' && activeFolder === id) setActiveFolder(null);
    }
  };

  const filteredFiles = activeFolder 
    ? files.filter(f => f.folderId === activeFolder)
    : files;

  return (
    <div className="animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <div className="flex items-center space-x-2 text-xs font-black uppercase tracking-widest text-gray-400 mb-2">
            <button onClick={() => setActiveFolder(null)} className="hover:text-root-gold transition-colors">Vault</button>
            {activeFolder && (
              <>
                <ChevronLeft size={12} className="rotate-180" />
                <span className="text-gray-900">{folders.find(f => f.id === activeFolder)?.name}</span>
              </>
            )}
          </div>
          <h2 className="text-4xl font-bold text-gray-900 serif">Digital Assets</h2>
        </div>
        <div className="flex space-x-3">
          <button 
            onClick={() => setIsModalOpen('folder')}
            className="flex items-center px-6 py-4 bg-white border border-gray-100 text-gray-900 font-black uppercase tracking-widest text-[10px] rounded-2xl shadow-sm hover:shadow-md transition-all"
          >
            <FolderPlus size={16} className="mr-3 text-root-gold" />
            New Folder
          </button>
          <button 
            onClick={() => setIsModalOpen('file')}
            className="flex items-center px-6 py-4 bg-root-dark text-white font-black uppercase tracking-widest text-[10px] rounded-2xl shadow-[0_20px_40px_-10px_rgba(12,26,37,0.3)] hover:bg-black transition-all"
          >
            <FilePlus size={16} className="mr-3 text-root-gold" />
            Upload Asset
          </button>
        </div>
      </div>

      {loading ? (
        <div className="py-40 flex flex-col items-center justify-center text-gray-300">
          <Loader2 className="animate-spin mb-6" size={40} />
          <p className="text-[10px] font-black uppercase tracking-widest">Accessing Encrypted Nodes...</p>
        </div>
      ) : (
        <div className="space-y-12">
          {/* Folders Section - Only show when not in a folder */}
          {!activeFolder && (
            <div>
              <p className="text-[10px] uppercase tracking-[0.3em] font-black text-gray-400 mb-6">Directory</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {folders.map(folder => (
                  <div key={folder.id} className="group relative">
                    <button 
                      onClick={() => setActiveFolder(folder.id)}
                      className="w-full bg-white p-8 rounded-3xl border border-gray-100 shadow-sm hover:border-root-gold hover:shadow-xl transition-all duration-500 text-left"
                    >
                      <Folder className="text-root-gold mb-6 group-hover:scale-110 transition-transform duration-500" size={32} />
                      <h3 className="text-sm font-black text-gray-900 uppercase tracking-widest truncate mb-2">{folder.name}</h3>
                      <p className="text-[10px] text-gray-400 font-bold uppercase">{files.filter(f => f.folderId === folder.id).length} Assets</p>
                    </button>
                    <button 
                      onClick={(e) => { e.stopPropagation(); deleteItem('folders', folder.id); }}
                      className="absolute top-6 right-6 p-2 text-gray-100 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Files List */}
          <div>
            <div className="flex items-center justify-between mb-6">
              <p className="text-[10px] uppercase tracking-[0.3em] font-black text-gray-400">
                {activeFolder ? 'Contents' : 'Recent Assets'}
              </p>
              {activeFolder && (
                <button onClick={() => setActiveFolder(null)} className="flex items-center text-[10px] font-black uppercase text-root-gold hover:underline">
                  <ChevronLeft size={14} className="mr-1" /> Back to root
                </button>
              )}
            </div>
            
            {filteredFiles.length === 0 ? (
              <div className="bg-white border-2 border-dashed border-gray-100 rounded-3xl p-20 text-center">
                <File className="mx-auto text-gray-100 mb-6" size={48} />
                <h4 className="text-lg font-bold text-gray-900 serif mb-2">No assets found</h4>
                <p className="text-xs text-gray-400 uppercase tracking-widest font-bold">Start by adding a document or clinical profile.</p>
              </div>
            ) : (
              <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-100">
                    <tr>
                      <th className="px-8 py-6 text-left text-[10px] font-black uppercase tracking-widest text-gray-400">Asset Name</th>
                      <th className="px-8 py-6 text-left text-[10px] font-black uppercase tracking-widest text-gray-400">Scope</th>
                      <th className="px-8 py-6 text-left text-[10px] font-black uppercase tracking-widest text-gray-400">Volume</th>
                      <th className="px-8 py-6 text-right text-[10px] font-black uppercase tracking-widest text-gray-400">Manage</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {filteredFiles.map(file => (
                      <tr key={file.id} className="group hover:bg-gray-50/50 transition-colors">
                        <td className="px-8 py-6">
                          <div className="flex items-center">
                            <div className="w-10 h-10 bg-blue-50 text-blue-500 rounded-xl flex items-center justify-center mr-4 group-hover:bg-blue-500 group-hover:text-white transition-all">
                              <File size={18} />
                            </div>
                            <div>
                              <p className="text-sm font-black text-gray-900 uppercase tracking-tighter">{file.name}</p>
                              <p className="text-[9px] text-gray-400 font-bold uppercase tracking-widest">Uploaded {file.createdAt?.toDate().toLocaleDateString()}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <span className="px-3 py-1 bg-gray-100 text-gray-500 text-[9px] font-black uppercase tracking-widest rounded-full">
                            {folders.find(f => f.id === file.folderId)?.name || 'Root'}
                          </span>
                        </td>
                        <td className="px-8 py-6 text-[10px] font-bold text-gray-400 uppercase">{file.size}</td>
                        <td className="px-8 py-6 text-right space-x-2">
                          <button className="p-2 text-gray-300 hover:text-root-gold transition-colors"><ExternalLink size={16} /></button>
                          <button onClick={() => deleteItem('files', file.id)} className="p-2 text-gray-300 hover:text-red-500 transition-colors"><Trash2 size={16} /></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal - Unified UI */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-root-dark/80 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in duration-300">
            <div className="p-12">
              <div className="flex justify-between items-center mb-10">
                <h4 className="text-2xl font-bold text-gray-900 serif">
                  {isModalOpen === 'folder' ? 'Define Sub-Directory' : 'Manifest Digital Asset'}
                </h4>
                <button onClick={() => setIsModalOpen(null)} className="w-10 h-10 flex items-center justify-center bg-gray-50 rounded-full text-gray-400 hover:text-gray-900 transition-all">
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleCreate} className="space-y-8">
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] font-black text-gray-400 mb-3">Asset Designation</label>
                  <input 
                    type="text" 
                    required
                    autoFocus
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-root-gold outline-none transition-all text-sm font-bold placeholder:text-gray-300"
                    placeholder={isModalOpen === 'folder' ? "e.g. Clinical Profiles" : "e.g. IEP_Standard_v1"}
                  />
                </div>

                {isModalOpen === 'file' && (
                  <div className="grid grid-cols-2 gap-4">
                    {!activeFolder && (
                      <div>
                        <label className="block text-[10px] uppercase tracking-[0.2em] font-black text-gray-400 mb-3">Directory</label>
                        <select 
                          value={selectedFolderId}
                          onChange={(e) => setSelectedFolderId(e.target.value)}
                          className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-root-gold outline-none text-[10px] font-black uppercase tracking-widest"
                        >
                          <option value="">(Root)</option>
                          {folders.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                        </select>
                      </div>
                    )}
                    <div className={activeFolder ? 'col-span-2' : ''}>
                      <label className="block text-[10px] uppercase tracking-[0.2em] font-black text-gray-400 mb-3">Est. Weight</label>
                      <input 
                        type="text"
                        value={fileSize}
                        onChange={(e) => setFileSize(e.target.value)}
                        className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-[10px] font-black uppercase tracking-widest outline-none"
                      />
                    </div>
                  </div>
                )}

                <div className="pt-4 flex space-x-4">
                  <button 
                    type="button"
                    onClick={() => setIsModalOpen(null)}
                    className="flex-1 py-5 text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-gray-900 transition-colors"
                  >
                    Abort
                  </button>
                  <button 
                    type="submit"
                    disabled={saving}
                    className="flex-1 py-5 bg-root-dark text-white font-black uppercase tracking-[0.2em] text-[10px] rounded-2xl shadow-xl flex items-center justify-center hover:bg-black transition-all"
                  >
                    {saving ? <Loader2 className="animate-spin" size={18} /> : 'Initialize'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FilesSection;
