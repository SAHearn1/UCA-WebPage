
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

// Using the required process.env.API_KEY for the main API key
const firebaseConfig = {
  apiKey: process.env.API_KEY,
  authDomain: "urban-christian-academy.firebaseapp.com",
  projectId: "urban-christian-academy",
  storageBucket: "urban-christian-academy.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef123456"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
