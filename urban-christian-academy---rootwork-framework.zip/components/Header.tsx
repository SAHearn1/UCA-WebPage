
import React from 'react';
import { Sprout, Menu, X, LogOut, User as UserIcon } from 'lucide-react';
import { User } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { auth } from '../services/firebase';
import { signOut } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

interface HeaderProps {
  onNavigate: (tab: 'home' | 'framework') => void;
  activeTab: string;
  user: User | null;
  onLogin: () => void;
}

const Header: React.FC<HeaderProps> = ({ onNavigate, activeTab, user, onLogin }) => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      onNavigate('home');
    } catch (err) {
      console.error("Logout error:", err);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-24">
          <div className="flex items-center cursor-pointer group" onClick={() => onNavigate('home')}>
            <div className="bg-root-dark p-2 rounded-lg mr-4 transition-transform group-hover:scale-105">
              <Sprout className="text-root-gold" size={28} />
            </div>
            <div>
              <span className="text-2xl font-bold text-gray-900 tracking-tight serif">Urban Christian Academy</span>
              <p className="text-[10px] uppercase tracking-[0.2em] text-root-gold font-extrabold">Powered by RootWork Framework</p>
            </div>
          </div>

          <nav className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => onNavigate('home')}
              className={`text-xs uppercase tracking-widest font-bold transition-all ${activeTab === 'home' ? 'text-gray-900 border-b-2 border-root-gold pb-1' : 'text-gray-400 hover:text-gray-900'}`}
            >
              The Vision
            </button>
            <button 
              onClick={() => onNavigate('framework')}
              className={`text-xs uppercase tracking-widest font-bold transition-all ${activeTab === 'framework' ? 'text-gray-900 border-b-2 border-root-gold pb-1' : 'text-gray-400 hover:text-gray-900'}`}
            >
              The Pedagogy
            </button>
            
            <div className="h-6 w-[1px] bg-gray-200" />

            {user ? (
              <div className="flex items-center space-x-6">
                <div className="flex items-center text-gray-900 space-x-2">
                  <UserIcon size={16} className="text-root-gold" />
                  <span className="text-[10px] uppercase tracking-widest font-bold max-w-[120px] truncate">{user.email}</span>
                </div>
                <button 
                  onClick={handleLogout}
                  className="flex items-center space-x-2 text-xs uppercase tracking-widest font-bold text-red-500 hover:text-red-700 transition-colors"
                >
                  <LogOut size={16} />
                  <span>Logout</span>
                </button>
              </div>
            ) : (
              <button 
                onClick={onLogin}
                className="text-xs uppercase tracking-widest font-bold text-root-gold border border-root-gold px-4 py-2 rounded hover:bg-root-gold hover:text-white transition-all"
              >
                Sign In
              </button>
            )}
          </nav>

          <div className="md:hidden">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-900">
              {isMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden bg-white border-b border-gray-100 py-6 px-4 space-y-6">
          <button onClick={() => { onNavigate('home'); setIsMenuOpen(false); }} className="block w-full text-left font-bold uppercase tracking-widest text-sm">The Vision</button>
          <button onClick={() => { onNavigate('framework'); setIsMenuOpen(false); }} className="block w-full text-left font-bold uppercase tracking-widest text-sm">The Pedagogy</button>
          {user ? (
            <button onClick={handleLogout} className="block w-full text-left font-bold uppercase tracking-widest text-sm text-red-500">Logout</button>
          ) : (
            <button onClick={() => { onLogin(); setIsMenuOpen(false); }} className="block w-full text-left font-bold uppercase tracking-widest text-sm text-root-gold">Sign In</button>
          )}
        </div>
      )}
    </header>
  );
};

export default Header;
