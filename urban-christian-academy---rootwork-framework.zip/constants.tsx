
import React from 'react';
import { 
  ShieldCheck, 
  Layout, 
  Cpu, 
  Database,
  Sprout,
  BookOpen,
  ArrowRight,
  Target,
  Zap,
  CheckCircle2,
  Search,
  Scale,
  Code
} from 'lucide-react';
import { FrameworkModule, Agent, AgentStatus } from './types';

export const FRAMEWORK_MODULES: FrameworkModule[] = [
  { id: "pedagogy", title: "Cultural Pedagogy", description: "Evidence-based instructional strategies rooted in urban community dynamics.", icon: "BookOpen" },
  { id: "lessonplan", title: "LP Generator", description: "AI-driven lesson planning aligned with RootWork standards.", icon: "Cpu" },
  { id: "lms", title: "Holistic LMS", description: "Learning Management system focused on character and academic growth.", icon: "Layout" },
  { id: "sis", title: "Unified SIS", description: "Student Information System bridging family and school data.", icon: "Database" }
];

// Initial definitions for parallel agents in the command center
export const AGENT_DEFINITIONS: Agent[] = [
  { 
    id: 'research', 
    name: 'Research Agent', 
    role: 'Sourcing UCA-CECS documents', 
    status: AgentStatus.IDLE, 
    progress: 0, 
    lastUpdate: 'Waiting to start...' 
  },
  { 
    id: 'compliance', 
    name: 'Compliance Agent', 
    role: 'Verifying legal framework', 
    status: AgentStatus.IDLE, 
    progress: 0, 
    lastUpdate: 'Waiting to start...' 
  },
  { 
    id: 'design', 
    name: 'Design Agent', 
    role: 'Optimizing UI components', 
    status: AgentStatus.IDLE, 
    progress: 0, 
    lastUpdate: 'Waiting to start...' 
  },
  { 
    id: 'engineering', 
    name: 'Engineering Agent', 
    role: 'Validating system logic', 
    status: AgentStatus.IDLE, 
    progress: 0, 
    lastUpdate: 'Waiting to start...' 
  }
];

// Mapping agent IDs to their respective Lucide icons
export const getIconForAgent = (id: string) => {
  switch (id) {
    case 'research': return <Search size={20} />;
    case 'compliance': return <Scale size={20} />;
    case 'design': return <Layout size={20} />;
    case 'engineering': return <Code size={20} />;
    default: return <Cpu size={20} />;
  }
};
