
import React, { useState, useEffect } from 'react';
import { User } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  serverTimestamp,
  deleteDoc,
  doc 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { db } from '../../services/firebase';
// Added Users icon to the imports from lucide-react
import { UserPlus, ShieldCheck, Mail, Loader2, X, MoreHorizontal, Shield, Star, Trash2, Users } from 'lucide-react';

interface TeamSectionProps {
  user: User;
}

const TeamSection: React.FC<TeamSectionProps> = ({ user }) => {
  const [members, setMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [role, setRole] = useState('Lead Educator');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'users', user.uid, 'teamMembers'), (snap) => {
      setMembers(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    });
    return () => unsub();
  }, [user.uid]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setSaving(true);
    try {
      await addDoc(collection(db, 'users', user.uid, 'teamMembers'), {
        name,
        role,
        createdAt: serverTimestamp(),
      });
      setIsModalOpen(false);
      setName('');
      setRole('Lead Educator');
    } catch (err) { console.error(err); }
    finally { setSaving(false); }
  };

  const removeMember = async (id: string) => {
    if (confirm('Revoke access for this team member?')) {
      await deleteDoc(doc(db, 'users', user.uid, 'teamMembers', id));
    }
  };

  return (
    <div className="animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h2 className="text-4xl font-bold text-gray-900 serif">Collaborators</h2>
          <p className="text-sm text-gray-500 mt-2 font-light">Bridge the gap between UCA educators and CECS clinical clinical specialists.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center px-8 py-5 bg-root-dark text-white font-black uppercase tracking-[0.2em] text-[10px] rounded-2xl shadow-[0_20px_40px_-10px_rgba(12,26,37,0.3)] hover:bg-black transition-all"
        >
          <UserPlus size={18} className="mr-3 text-root-gold" />
          Assign Partner
        </button>
      </div>

      {loading ? (
        <div className="py-40 flex justify-center"><Loader2 className="animate-spin text-gray-200" size={40} /></div>
      ) : members.length === 0 ? (
        <div className="bg-white border-2 border-dashed border-gray-100 rounded-[3rem] p-24 text-center">
          <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-8 text-gray-200">
            {/* Fix: Users component is now correctly imported */}
            <Users size={32} />
          </div>
          <h4 className="text-2xl font-bold text-gray-900 serif mb-4">No Active Caseload</h4>
          <p className="text-sm text-gray-400 max-w-sm mx-auto font-light leading-relaxed">Assigned CECS therapists and UCA faculty will appear here once you assign them to your workspace.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {members.map(member => (
            <div key={member.id} className="group bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-2xl transition-all duration-700 relative overflow-hidden">
              <div className="absolute top-8 right-8 space-x-2 flex">
                <button 
                  onClick={() => removeMember(member.id)}
                  className="p-2 text-gray-100 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                >
                  <Trash2 size={16} />
                </button>
              </div>

              <div className="flex items-center space-x-6 mb-10">
                <div className="w-20 h-20 bg-gray-50 rounded-[1.5rem] flex items-center justify-center text-root-gold font-black text-2xl border border-gray-100 shadow-inner group-hover:bg-root-dark group-hover:text-white transition-all duration-500">
                  {member.name?.[0]}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 serif group-hover:text-root-gold transition-colors">{member.name}</h3>
                  <div className="flex items-center space-x-2 mt-2">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Available</span>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-2xl p-6 mb-8 border border-gray-50">
                <div className="flex items-center text-[10px] uppercase tracking-widest text-root-gold font-black mb-3">
                  <ShieldCheck size={12} className="mr-2" />
                  <span>Verified Credentials</span>
                </div>
                <p className="text-[11px] font-black uppercase tracking-widest text-gray-900">{member.role}</p>
              </div>

              <div className="pt-8 border-t border-gray-50 flex justify-between items-center">
                <button className="text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-root-dark transition-colors flex items-center group/btn">
                  <Mail size={14} className="mr-2 group-hover/btn:scale-110 transition-transform" />
                  Request Meeting
                </button>
                <div className="flex items-center space-x-1">
                  {[1, 2, 3, 4].map(i => <Star key={i} size={8} className="fill-root-gold text-root-gold" />)}
                  <Star size={8} className="text-gray-200" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Team Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-root-dark/80 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in duration-300">
            <div className="p-16">
              <div className="flex justify-between items-center mb-12">
                <h4 className="text-2xl font-bold text-gray-900 serif">Manifest Caseload</h4>
                <button onClick={() => setIsModalOpen(false)} className="w-12 h-12 flex items-center justify-center bg-gray-50 rounded-full text-gray-400 hover:text-gray-900 transition-all">
                  <X size={24} />
                </button>
              </div>

              <form onSubmit={handleCreate} className="space-y-10">
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] font-black text-gray-400 mb-4">Partner Identity</label>
                  <input 
                    type="text" 
                    required
                    autoFocus
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-6 py-5 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-root-gold outline-none text-sm font-bold"
                    placeholder="E.g., Dr. Elijah Vance"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] font-black text-gray-400 mb-4">Structural Designation</label>
                  <select 
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    className="w-full px-6 py-5 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-root-gold outline-none text-[10px] font-black uppercase tracking-widest"
                  >
                    <option value="Lead Educator">Lead Educator (UCA)</option>
                    <option value="Clinical Partner (CECS)">Clinical Partner (CECS)</option>
                    <option value="Behavioral Specialist">Behavioral Specialist</option>
                    <option value="Case Architect">Case Architect</option>
                  </select>
                </div>
                
                <button 
                  type="submit" 
                  disabled={saving} 
                  className="w-full py-6 bg-[#B8860B] text-white text-[11px] font-black uppercase tracking-[0.3em] rounded-2xl shadow-2xl hover:bg-[#8B6508] transition-all flex items-center justify-center"
                >
                  {saving ? <Loader2 className="animate-spin" size={18} /> : 'Authorize Assignment'}
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeamSection;
