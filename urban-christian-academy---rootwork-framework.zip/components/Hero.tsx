
import React from 'react';
import { ArrowRight, Star, GraduationCap, Users, UserCheck, PlayCircle, Sparkles } from 'lucide-react';
import { User } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

interface HeroProps {
  onAuthRequired: (mode: 'signin' | 'signup') => void;
  user: User | null;
}

const Hero: React.FC<HeroProps> = ({ onAuthRequired, user }) => {
  return (
    <div className="relative min-h-screen flex items-center bg-[#fdfdfd] overflow-hidden">
      {/* Background Architectural Element with Garden Theme */}
      <div className="absolute top-0 right-0 w-full lg:w-3/5 h-full bg-root-dark z-0">
        <div className="absolute inset-0 opacity-40">
          <img 
            src="https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&q=80&w=1600" 
            alt="Lush Urban Garden"
            className="w-full h-full object-cover grayscale brightness-50"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-[#fdfdfd] via-transparent to-transparent lg:block hidden" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-20 lg:py-0">
        <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center space-x-3 px-4 py-2 bg-white shadow-sm border border-gray-100 rounded-full">
              <Sparkles size={16} className="text-root-gold" />
              <span className="text-[10px] uppercase tracking-[0.3em] font-black text-gray-900">Transformation Engine</span>
            </div>
            
            <h1 className="text-6xl md:text-8xl font-bold tracking-tight text-gray-900 serif leading-[0.9] lg:leading-[0.85]">
              Urban <br />
              <span className="text-root-gold">Excellence</span> <br />
              Redefined.
            </h1>
            
            <p className="max-w-md text-lg text-gray-500 font-light leading-relaxed">
              Urban Christian Academy x CECS: Deploying the RootWork Framework™ to bridge the gap between clinical insight and academic mastery.
            </p>
            
            {/* Action Buttons */}
            <div className="space-y-4 max-w-md">
              <div className="grid grid-cols-2 gap-4">
                <button 
                  onClick={() => !user && onAuthRequired('signup')}
                  className="flex items-center justify-center space-x-2 px-6 py-5 bg-[#B8860B] text-white font-bold uppercase tracking-widest text-[10px] rounded shadow-2xl hover:bg-[#8B6508] transition-all border border-[#966F00] group"
                >
                  <GraduationCap size={16} className="group-hover:scale-110 transition-transform" />
                  <span>Registration</span>
                </button>
                <button 
                  onClick={() => !user && onAuthRequired('signin')}
                  className="flex items-center justify-center space-x-2 px-6 py-5 border-2 border-root-gold text-root-gold font-bold uppercase tracking-widest text-[10px] rounded hover:bg-root-gold hover:text-white transition-all shadow-lg"
                >
                  <UserCheck size={16} />
                  <span>Student Login</span>
                </button>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <button 
                  onClick={() => !user && onAuthRequired('signin')}
                  className="flex items-center justify-center space-x-2 px-6 py-5 border-2 border-gray-900 text-gray-900 font-bold uppercase tracking-widest text-[10px] rounded hover:bg-gray-900 hover:text-white transition-all"
                >
                  <Users size={16} />
                  <span>Staff Portal</span>
                </button>
                <button className="flex items-center justify-center space-x-2 px-6 py-5 bg-root-dark text-white font-bold uppercase tracking-widest text-[10px] rounded shadow-2xl hover:bg-black transition-all border border-gray-700">
                  <PlayCircle size={16} className="text-root-gold" />
                  <span>The Vision</span>
                </button>
              </div>
            </div>

            <div className="pt-8 flex items-center space-x-12">
              <div>
                <p className="text-2xl font-bold text-gray-900 serif">100%</p>
                <p className="text-[9px] uppercase tracking-widest font-black text-root-gold">CCSS Aligned</p>
              </div>
              <div className="h-8 w-[1px] bg-gray-200" />
              <div>
                <p className="text-2xl font-bold text-gray-900 serif">Proprietary</p>
                <p className="text-[9px] uppercase tracking-widest font-black text-root-gold">AI-Ecosystem</p>
              </div>
            </div>
          </div>

          <div className="hidden lg:block relative group">
            <div className="relative">
              {/* Main Subject Image - Black and Brown people in garden school setting */}
              <div className="relative z-10 w-full h-[700px] rounded-3xl overflow-hidden shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)] border-8 border-white bg-gray-100">
                <img
                  src="https://images.unsplash.com/photo-1594608661623-aa0bd3a69d98?auto=format&fit=crop&q=80&w=1200"
                  alt="Children of color gardening in school"
                  className="w-full h-full object-cover transition-all duration-1000 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-root-dark/40 via-transparent to-transparent pointer-events-none" />
              </div>

              {/* Decorative Floating Card */}
              <div className="absolute -bottom-10 -left-10 z-20 bg-white p-8 rounded-2xl shadow-2xl max-w-xs border border-gray-100 transform -rotate-2 group-hover:rotate-0 transition-transform">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center">
                    <Star className="text-root-gold" size={20} />
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Faculty Insight</span>
                </div>
                <p className="text-gray-900 text-sm font-bold serif leading-relaxed">
                  "The Framework doesn't just teach tasks; it roots the identity of our children in possibility."
                </p>
                <div className="mt-4 pt-4 border-t border-gray-50 flex items-center justify-between">
                  <span className="text-[9px] uppercase tracking-tighter font-black text-root-gold">UCA x CECS Certified</span>
                  <div className="flex -space-x-2">
                    <div className="w-6 h-6 rounded-full bg-gray-200 border-2 border-white" />
                    <div className="w-6 h-6 rounded-full bg-gray-300 border-2 border-white" />
                  </div>
                </div>
              </div>

              {/* Accent Circles */}
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-root-gold/20 rounded-full blur-3xl animate-pulse" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
