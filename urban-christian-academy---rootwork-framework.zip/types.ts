
// Enum representing the operational state of an AI agent
export enum AgentStatus {
  IDLE = 'IDLE',
  RUNNING = 'RUNNING',
  COMPLETED = 'COMPLETED'
}

// Interface for agent objects managed by the orchestrator
export interface Agent {
  id: string;
  name: string;
  role: string;
  status: AgentStatus;
  progress: number;
  lastUpdate: string;
}

export interface GroundingLink {
  title: string;
  uri: string;
}

export interface FrameworkModule {
  id: string;
  title: string;
  description: string;
  icon: string;
}
