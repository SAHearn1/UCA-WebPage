
import React from 'react';
import { Sprout, Mail, MapPin, Phone } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center mb-6">
              <Sprout className="text-root-gold mr-3" size={32} />
              <span className="text-2xl font-bold serif">Urban Christian Academy</span>
            </div>
            <p className="text-gray-400 max-w-sm mb-8">
              A community focused on character, faith, and academic excellence, powered by the RootWork Framework and CECS innovation.
            </p>
            <div className="flex space-x-4">
              <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 cursor-pointer">
                <Mail size={18} />
              </div>
              <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 cursor-pointer">
                <MapPin size={18} />
              </div>
              <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 cursor-pointer">
                <Phone size={18} />
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="text-root-gold font-bold uppercase tracking-widest text-xs mb-6">The Framework</h4>
            <ul className="space-y-4 text-sm text-gray-400">
              <li className="hover:text-white cursor-pointer transition-colors">Methodology Overview</li>
              <li className="hover:text-white cursor-pointer transition-colors">Lesson Plan Generator</li>
              <li className="hover:text-white cursor-pointer transition-colors">Holistic LMS</li>
              <li className="hover:text-white cursor-pointer transition-colors">Unified SIS</li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-root-gold font-bold uppercase tracking-widest text-xs mb-6">Community</h4>
            <ul className="space-y-4 text-sm text-gray-400">
              <li className="hover:text-white cursor-pointer transition-colors">CECS Partnership</li>
              <li className="hover:text-white cursor-pointer transition-colors">Student Admissions</li>
              <li className="hover:text-white cursor-pointer transition-colors">Family Portal</li>
              <li className="hover:text-white cursor-pointer transition-colors">Support Hub</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500">
          <p>© 2024 Urban Christian Academy. All Rights Reserved. The RootWork Framework is a registered trademark of CECS.</p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <span className="hover:text-white cursor-pointer">Privacy Policy</span>
            <span className="hover:text-white cursor-pointer">Terms of Service</span>
            <span className="hover:text-white cursor-pointer">Legal Compliance</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
